#pragma once

#define MYICON 101

#define IDBITMAP_STONE 102

#define IDBITMAP_KUNDALI 103
