#pragma once

#define MYICON 101

#define IDBITMAP_SMILEY 102


